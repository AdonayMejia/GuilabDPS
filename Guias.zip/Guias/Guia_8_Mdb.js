use Tienda

db.createCollection("Productos")

var $datos=[
    {nombre:"Aceite",presentacion:{cantidad:"900",unidad:"Ml"},precio:4,proveedor:"Molino"},
    
    {nombre:"Aceite",presentacion:{cantidad:"1",unidad:"Lt"},precio:4.33,proveedor:"Molino"},
    
    {nombre:"Arroz",presentacion:{cantidad:"1",unidad:"Kg"},precio:1.69,proveedor:"San Franciso"},
    
    {nombre:"Arvejas",presentacion:{cantidad:"1",unidad:"Kg"},precio:1.88},
    
    {nombre:"Azucar",presentacion:{cantidad:"1",unidad:"Kg"},precio:1.72,proveedor:"Ca�al"},
    
    {nombre:"Frijol",presentacion:{cantidad:"1",unidad:"Kg"},precio:2.83},
    
    {nombre:"Carne de Primera",presentacion:{cantidad:"1",unidad:"Kg"},precio:5.63,proveedor:"Selectos"},
    
    {nombre:"Carne de Segunda",presentacion:{cantidad:"1",unidad:"Kg"},precio:3.50,proveedor:"Selectos"},
    
    {nombre:"Harina de Trigo",presentacion:{cantidad:"1",unidad:"Kg"},precio:2.86,proveedor:"Molino"},
    
    {nombre:"Harina Precocida",presentacion:{cantidad:"1",unidad:"Kg"},precio:1.63,proveedor:"Molino"},
    
    {nombre:"Lacteos",presentacion:{cantidad:"500",unidad:"Grs"},precio:2.70},
    
    {nombre:"Leche en Polvo",presentacion:{cantidad:"1",unidad:"Kg"},precio:7.89},
   
    {nombre:"Lentejas",presentacion:{cantidad:"1",unidad:"Kg"},precio:2.02},
    
    {nombre:"Margarina",presentacion:{cantidad:"500",unidad:"Grs"},precio:1.66,proveedor:"Molino"},
    
    {nombre:"Mortadela",presentacion:{cantidad:"1",unidad:"Kg"},precio:5.10,proveedor:"Selectos"},
    
    {nombre:"Pasta Corta",presentacion:{cantidad:"1",unidad:"Kg"},precio:1.96},
    
    {nombre:"Pasta Larga",presentacion:{cantidad:"1",unidad:"Kg"},precio:1.96},
    
    {nombre:"Pollo",presentacion:{cantidad:"1",unidad:"Kg"},precio:5.03},

    ]
    
db.Productos.insert($datos)
    
db.Productos.find()

db.Productos.find({"presentacion.unidad":"Grs"})

db.Productos.find({proveedor:{$exists:true}})

db.Productos.find({proveedor:{$exists:false}})

db.Productos.find({precio:{$lt:5}})

db.Productos.find({precio:{$gte:5}})

db.Productos.find({precio:{$lt:7,$gte:3}})

db.Productos.find({},{"nombre":1,"_id":0})

db.Productos.find({"proveedor":{$type:2}})

db.Productos.find({$or:[{"precio":{$lte:1}},{"nombre":{$gte:"M"}}]})

db.Productos.find({$and:[{"proveedor":{$exists:true}},{"nombre":{$gte:"M"}}]})

db.Productos.find({nombre:{$regex:"^C"}})

db.Productos.find({nombre:{$regex:"a$"}})

/*Cambiar cantidades a enteros*/
db.Productos.aggregate([
{$group: {_id:"$presentacion.unidad", total: {$sum:"$presentacion.cantidad"}}},
{$sort:{total:-1}}
])

db.Productos.aggregate([
{$group: {_id:"$presentacion.unidad", total: {$avg:"$precio"}}},
{$sort:{total:-1}}
])

db.Productos.aggregate([
{$group: {_id:"$presentacion.unidad", Maximo: {$max:"$precio"}}},
{$sort:{Maximo:-1}}
])

db.Productos.aggregate([
{$group: {_id:"$nombre", Minimo: {$min:"$precio"}}},
{$sort:{Minimo:1}},{$limit:1}
])