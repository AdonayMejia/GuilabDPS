db.createCollection("Autor",
    {validator: {$or :
        [
            {nombre: {$type:"string"}},
            {biografia: {$type:"string"}},
            {fecha_de_nacimiento: {$type:"date"}},
            {nacionalidad: {$type: "string"}}
        ]
            }
})

db.createCollection("Libros",
    {validator: {$or :
        [
            {titulo: {$type:"string"}},
            {paginas: {$type:"int"}},
            {isbn: {$type:"string"}},
            {autor: [{$type: "objectId"},$ref:"Autor"]}
        ]
            }
})

var $datosAutor=[
        {"_id":"AU001", "nombre": "George R. R. Martin", "biografia": "American novelist..", 
            "fecha_de_nacimiento": ISODate("1948-09-02"), "nacionalidad":"USA"},
            
        {"_id":"AU002", "nombre": "George R. R. Martin", "biografia": "American novelist..", 
            "fecha_de_nacimiento": ISODate("1948-09-02"), "nacionalidad":"USA"},
            
        {"_id":"AU003", "nombre": "George R. R. Martin", "biografia": "American novelist..", 
            "fecha_de_nacimiento": ISODate("1948-09-02"), "nacionalidad":"USA"},
            
        {"_id":"", "nombre": "", "biografia": "", 
            "fecha_de_nacimiento": ISODate(""), "nacionalidad":""},
            
        {"_id":"", "nombre": "", "biografia": "", 
            "fecha_de_nacimiento": ISODate(""), "nacionalidad":""}
]